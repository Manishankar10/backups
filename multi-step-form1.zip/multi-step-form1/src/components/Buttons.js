import React from "react";
import { Col, Row } from "react-bootstrap";

export default function Buttons({
  pagenum,
  FormTitle,
  setinfo,
  setinfo1,
  setinfo2,
  setinfo3,
  setPagenum,
}) {
  const handleButton = () => {
    setPagenum((pagenum) => pagenum + 1);
    if (pagenum === 0) {
      setinfo(false);
      setinfo1(true);
      setinfo2(false);
      setinfo3(false);
    } else if (pagenum === 1) {
      setinfo(false);
      setinfo1(false);
      setinfo2(true);
      setinfo3(false);
    } else {
      setinfo(false);
      setinfo1(false);
      setinfo2(false);
      setinfo3(true);
    }
  };
  const handleSubmit = () => {
    alert("SUBMITTED SUCCESSFULLY");
    setPagenum(0);
    setinfo(true);
    setinfo1(false);
    setinfo2(false);
    setinfo3(false);
  };
  return (
    <div>
      <Row>
        <Col xs={5} sm={4} lg={3}>
          {pagenum === FormTitle.length - 1 ? (
            <button
              className="continue border border-info text-info rounded-pill buton"
              onClick={() => {
                handleSubmit();
              }}
            >
              Submit
            </button>
          ) : (
            <button
              className="continue border border-info text-info rounded-pill buton"
              onClick={() => {
                handleButton();
              }}
            >
              Continue
            </button>
          )}
        </Col>{" "}
      </Row>
    </div>
  );
}
