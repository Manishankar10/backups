import React from "react";
import { Form } from "react-bootstrap";

export default function ClientInfo() {
  return (
    <div>
      <Form>
        <Form.Group controlId="form.password">
          <Form.Label>Client-Passcode</Form.Label>
          <Form.Control type="password" placeholder="Enter Passcode" />
        </Form.Group>
        <Form.Group controlId="form.Email">
          <Form.Label>Customer Email address</Form.Label>
          <Form.Control type="email" placeholder="name@example.com" />
        </Form.Group>
        <Form.Group controlId="form.Textarea">
          <Form.Label>Customer-info</Form.Label>
          <Form.Control as="textarea" rows={3} />
        </Form.Group>
      </Form>
    </div>
  );
}
