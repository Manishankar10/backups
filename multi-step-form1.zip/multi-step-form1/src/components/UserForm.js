import React, { useState } from "react";
import EmaillDetails from "./EmailDetails";
import ClientInfo from "./ClientInfo";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Popup from "./Popup";
import {
  faClipboardCheck,
  fa3,
  faChevronRight,
  fa2,
  fa1,
  fa4,
} from "@fortawesome/free-solid-svg-icons";
import QuoteInfo from "./QuoteInfo";
import { Col, Row } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Submission from "./Submission";
import Buttons from "./Buttons";

// import TopNavbar from "./TopNavbar";
export default function UserForm() {
  const [pagenum, setPagenum] = useState(0);
  const [info, setinfo] = useState(true);
  const [info1, setinfo1] = useState(false);
  const [info2, setinfo2] = useState(false);
  const [info3, setinfo3] = useState(false);

  const FormTitle = [
    "Quote Information",
    "ClientInfo",
    "EmailDetails",
    "Submissions",
  ];

  const pageDisplay = () => {
    switch (pagenum) {
      case 0:
        return <QuoteInfo />;
      case 1:
        return <ClientInfo />;
      case 2:
        return <EmaillDetails />;
      case 3:
        return <Submission />;
      default:
        return null;
    }
  };

  return (
    <div className="container mt-5 pt-5 overflow-auto">
      <div className="userform p-5 ">
        <div className="d-flex mb-3">
          <FontAwesomeIcon
            size="2x"
            className="bg-info rounded-circle pt-3 pb-4 ps-4 pe-4 text-white"
            icon={faClipboardCheck}
          />
          <div>
            <div className="ms-3 text-muted ic">SUPPORTED EMPLOYEE</div>
            <div className="ms-3 fs-4">
              <strong>REQUEST</strong> A QUOTE
            </div>
          </div>
        </div>

        {/* Navigation bar  */}
        <div className="ms-2 cs text-white rounded overflow-auto">
          <div className="row ">
            <div className="col-12">
              <div className="d-flex col-xs-12 col-sm-12 col-md-12 col-lg-12 ">
                {info ? (
                  <Button
                    className="rounded-circle"
                    size="lg"
                    style={{ backgroundColor: "#318dcf" }}
                  >
                    <FontAwesomeIcon size="lg" icon={fa1} />
                  </Button>
                ) : (
                  <Button
                    className="rounded-circle"
                    size="lg"
                    style={{
                      backgroundColor: "rgb(10, 25, 77)",
                      color: "#166094",
                      borderColor: "#166094",
                    }}
                  >
                    <FontAwesomeIcon size="lg" icon={fa1} />
                  </Button>
                )}
                {info ? (
                  <div className="pt-2 ms-2 fs-5">{FormTitle[pagenum]}</div>
                ) : null}
                <FontAwesomeIcon
                  size="2x"
                  className="arrow p-2"
                  icon={faChevronRight}
                />
                {info1 ? (
                  <Button
                    className="rounded-circle"
                    size="lg"
                    style={{ backgroundColor: "#318dcf" }}
                  >
                    <FontAwesomeIcon size="lg" icon={fa2} />
                  </Button>
                ) : (
                  <Button
                    className="rounded-circle"
                    size="lg"
                    style={{
                      backgroundColor: "rgb(10, 25, 77)",
                      color: "#166094",
                      borderColor: "#166094",
                    }}
                  >
                    <FontAwesomeIcon size="lg" icon={fa2} />
                  </Button>
                )}
                {info1 ? (
                  <div className="pt-2 ms-2 fs-5">{FormTitle[pagenum]}</div>
                ) : null}
                <FontAwesomeIcon
                  size="2x"
                  className="arrow p-2"
                  icon={faChevronRight}
                />
                {info2 ? (
                  <Button
                    className="rounded-circle"
                    size="lg"
                    style={{ backgroundColor: "#318dcf" }}
                  >
                    <FontAwesomeIcon size="lg" icon={fa3} />
                  </Button>
                ) : (
                  <Button
                    className="rounded-circle"
                    size="lg"
                    style={{
                      backgroundColor: "rgb(10, 25, 77)",
                      color: "#166094",
                      borderColor: "#166094",
                    }}
                  >
                    <FontAwesomeIcon size="lg" icon={fa3} />
                  </Button>
                )}
                {info2 ? (
                  <div className="pt-2 ms-2 fs-5">{FormTitle[pagenum]}</div>
                ) : null}
                <FontAwesomeIcon
                  size="2x"
                  className="arrow p-2"
                  icon={faChevronRight}
                />
                {info3 ? (
                  <Button
                    className="rounded-circle"
                    size="lg"
                    style={{ backgroundColor: "#318dcf" }}
                  >
                    <FontAwesomeIcon size="lg" icon={fa4} />
                  </Button>
                ) : (
                  <Button
                    className=" rounded-circle"
                    size="lg"
                    style={{
                      backgroundColor: "rgb(10, 25, 77)",
                      color: "#166094",
                      borderColor: "#166094",
                    }}
                  >
                    <FontAwesomeIcon size="lg" icon={fa4} />
                  </Button>
                )}
                {info3 ? (
                  <div className="pt-2 ms-2 fs-5">{FormTitle[pagenum]}</div>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        {/*Rendering pages */}
        <div className="overflow-auto">{pageDisplay()}</div>

        {/* Continue and Cancel Buttons*/}
        <div className="overflow-auto">
          <Row>
            <Col xs={6} sm={8} lg={9} className="mt-2">
              <Popup
                setPagenum={setPagenum}
                setinfo={setinfo}
                setinfo1={setinfo1}
                setinfo2={setinfo2}
                setinfo3={setinfo3}
              />
            </Col>
            <Col xs={6} sm={4} lg={3}>
              <Buttons
                pagenum={pagenum}
                FormTitle={FormTitle}
                setinfo={setinfo}
                setinfo1={setinfo1}
                setinfo2={setinfo2}
                setinfo3={setinfo3}
                setPagenum={setPagenum}
              />
            </Col>
          </Row>
        </div>
      </div>
    </div>
  );
}
