import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleCheck } from "@fortawesome/free-solid-svg-icons";

export default function Submission() {
  return (
    <div className="mt-5 overflow-hidden">
      {" "}
      <div className="row green">
        <div className="text-center">
          <FontAwesomeIcon size="3x" icon={faCircleCheck} />
        </div>
      </div>
      <div className="row green">
        <div>
          <div className="text-center mt-4 ms-4">
            <h3>Ready for Submission</h3>
          </div>
        </div>
      </div>
    </div>
  );
}
