import React, { useState } from "react";
import { Button, Modal } from "react-bootstrap";

export default function Popup({
  setPagenum,
  setinfo,
  setinfo1,
  setinfo2,
  setinfo3,
}) {
  const [show, setShow] = useState(false);

  const handleClose = () => {
    setShow(false);
  };
  const handleShow = () => setShow(true);
  const handleYes = () => {
    setShow(false);
    setPagenum(0);
    setinfo(true);
    setinfo1(false);
    setinfo2(false);
    setinfo3(false);
  };
  return (
    <div>
      <button className="no-b" onClick={handleShow}>
        Cancel
      </button>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>WARNING</Modal.Title>
        </Modal.Header>
        <Modal.Body>Are you sure to discard the Information!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleYes}>
            YES
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
