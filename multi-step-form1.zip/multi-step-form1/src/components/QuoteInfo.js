import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { Col, Form, Row } from "react-bootstrap";
import { faCircleExclamation } from "@fortawesome/free-solid-svg-icons";

export default function QuoteInfo() {
  return (
    <div>
      <form>
        <Row>
          <Col xs={6} lg={4}>
            <div className="muted">Solution Type</div>
            <div>
              <h6>Supported Employee</h6>
            </div>
          </Col>
          <Col xs={6} lg={4}>
            <div className="muted">Client</div>
            <div>
              <h6>GPT International</h6>
            </div>
          </Col>
          <Col xs={12} lg={4}>
            <div className="muted">Quote Submitted By</div>
            <div>
              <h6>John Doe</h6>
            </div>
          </Col>
        </Row>
        <Row>
          <Col sm={12} md={7} lg={4}>
            <select className="muted selector mt-5">
              <option value="selected">End Client</option>
              <option>IELTS</option>
              <option>PTE Academy</option>
              <option>GPT Overseas</option>
            </select>
          </Col>
          <Col sm={12} md={5} lg={8} className="mt-5 pt-1">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
              }}
            >
              Add a new End Client
            </a>
          </Col>
        </Row>
        <Row>
          <Col sm={12} lg={4}>
            <div>
              <select className="muted selector mt-5">
                <option value="selected">Country of Employement</option>
                <option>India</option>
                <option>United States</option>
                <option>Australia</option>
              </select>
            </div>
            <div className="muted fst-italic">(Required)</div>
          </Col>
          <Col sm={12} lg={8}>
            <select className="muted selector mt-5">
              <option value="selected">State/Province of Employement</option>
              <option>Queensland</option>
              <option>Tasmania</option>
              <option>New South Wales</option>
            </select>
          </Col>
        </Row>
        <Row className="d-flex mt-4">
          <Col className="d-flex" xs={12} sm={12} md={5} lg={5}>
            <p>Does your company have an entity in this country?</p>
            <FontAwesomeIcon
              className="text-info mt-1 ms-2"
              icon={faCircleExclamation}
            />
          </Col>
          <Col xs={12} sm={12} md={7} lg={7} className="d-flex">
            <Form.Check
              inline
              label="Yes"
              name="group1"
              type={"radio"}
              className="px-3"
              id={`inline-radio-1`}
            />

            <Form.Check
              className="ms-5"
              inline
              label="No"
              name="group1"
              type={"radio"}
              id={`inline-radio-2`}
            />
          </Col>
        </Row>
        <div></div>
      </form>
    </div>
  );
}
