import React, { useEffect, useLayoutEffect, useState } from 'react';
 export default function Effects(){
    const [num,setNum]=useState(0)
    useEffect(()=>{
        console.log("Useeffect")
        return ()=>{
            console.log("Unmounted")
        }
    },[num])
    useLayoutEffect(()=>{
        console.log("useLayoutEffect")
    },[num])
    return(<div>
        <button onClick={()=>{setNum(num=>num+1)}}>CLICK ME</button>
        {num}
    </div>)
 }