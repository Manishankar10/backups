import Effects from "./components/effects";

function App() {
  return (
    <div className="App">
      <Effects />
    </div>
  );
}

export default App;
