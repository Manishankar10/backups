import { faCloudArrowUp } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AddProperty() {
  const [state, setState] = useState({
    address: "",
    location: "",
    price: "",
    description: "",
    status: "",
  });

  const handleChange = (e) => {
    setState((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };
  const navigate = useNavigate();

  const handleSubmit = () => {
    navigate("/propertyList",{state:state});
  };
  return (
    <div className="gray apform">
      <div className="fnt ms-1p">Add / Edit Property</div>
      <div className="pad">
        <div className="ms-Grid">
          <div className="fif">
            Fill in the form
            <form>
              <div className="ms-Grid-row flx">
                <div className="ms-Grid-col ms-lg6">
                  <div className="fnt3">
                    <div>
                      {" "}
                      <label>Property Name</label>
                      <div>
                        <input
                          onChange={(e) => {
                            handleChange(e);
                          }}
                          name="address"
                          type="text"
                          className="inp"
                          placeholder="Enter title"
                        />
                      </div>
                    </div>
                    <div className="mar">
                      {" "}
                      <label>Location</label>
                      <div>
                        <input
                          onChange={(e) => {
                            handleChange(e);
                          }}
                          name="location"
                          className="inp"
                          placeholder="Enter Location"
                        />
                      </div>
                    </div>
                    <div className="mar">
                      {" "}
                      <label>Description</label>
                      <div>
                        <textarea
                        name="description"
                          onChange={(e) => {
                            handleChange(e);
                          }}
                          className="inp1"
                        />
                      </div>
                    </div>
                    <div className="mar">
                      {" "}
                      <label>Property Type</label>
                      <div className="chk">
                        <input
                          onClick={(e) => {
                            handleChange(e);
                          }}
                          type="radio"
                          value="Rent"
                          id="rent"
                          name="status"
                        />
                        <label for="rent">For Rent</label>
                        <input
                        onClick={(e) => {
                          handleChange(e);
                        }}
                          className="p-3"
                          type="radio"
                          value="Sale"
                          id="sale"
                          name="status"
                        />
                        <label for="sale">For Sale</label>
                      </div>
                    </div>
                    <div className="mar">
                      {" "}
                      <label>Price / Rent</label>
                      <div>
                        <input
                        name="price"
                          onChange={(e) => {
                            handleChange(e);
                          }}
                          className="inp"
                          placeholder="Enter number"
                        />
                      </div>
                    </div>
                    <div className="ms-Grid">
                      <div className="ms-Grid-row flx">
                        <div className="ms-Grid-col ms-lg4">
                          <label>Bedrooms</label>
                          <div className="mar">
                            {" "}
                            <input className="inp4" />
                          </div>
                        </div>
                        <div className="ms-Grid-col ms-lg4">
                          <label>Square ft</label>
                          <div className="mar">
                            {" "}
                            <input className="inp4" />
                          </div>
                        </div>
                        <div className="ms-Grid-col ms-lg4">
                          <label>Car Parking</label>
                          <div className="mar">
                            {" "}
                            <input className="inp4" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="ms-Grid-col ms-lg6">
                  <div className="fnt3">
                    <label>General Amenities</label>
                    <div className="flx">
                      <div className="padd">
                        <div className="padd">
                          <input
                            className="chks"
                            type="checkbox"
                            id="ch1"
                            name="addcheck"
                          />
                          <label for="ch1">Swimming pool</label>
                        </div>
                        <div className="padd">
                          {" "}
                          <input type="checkbox" id="ch2" name="addcheck" />
                          <label for="ch2">Terrace</label>
                          <br />
                        </div>
                        <div className="padd">
                          {" "}
                          <input type="checkbox" id="ch3" name="addcheck" />
                          <label for="ch3">Air conditioning</label>
                        </div>
                        <div className="padd">
                          {" "}
                          <input type="checkbox" id="ch4" name="addcheck" />
                          <label for="ch4">Internet</label>
                        </div>
                        <div className="padd">
                          <input type="checkbox" id="ch5" name="addcheck" />
                          <label for="ch5">Balcony</label>
                        </div>
                        <div className="padd">
                          <input type="checkbox" id="ch6" name="addcheck" />
                          <label for="ch6">Cable TV</label>
                        </div>
                        <div className="padd">
                          <input type="checkbox" id="ch7" name="addcheck" />
                          <label for="ch7">Computer</label>
                        </div>
                        <div className="padd">
                          <input type="checkbox" id="ch8" name="addcheck" />
                          <label for="ch8">Grill</label>
                        </div>
                      </div>
                      <div>
                        <div className="padd">
                          <div className="padd">
                            <input type="checkbox" id="ch9" name="addcheck" />
                            <label for="ch9">Dishwasher</label>
                          </div>
                          <div className="padd">
                            {" "}
                            <input type="checkbox" id="ch10" name="addcheck" />
                            <label for="ch10">Near Green Zone</label>
                          </div>
                          <div className="padd">
                            <input type="checkbox" id="ch11" name="addcheck" />
                            <label for="ch11">Near Church</label>
                          </div>
                          <div className="padd">
                            <input type="checkbox" id="ch12" name="addcheck" />
                            <label for="ch12">Near Hospital</label>
                          </div>
                          <div className="padd">
                            <input type="checkbox" id="ch13" name="addcheck" />
                            <label for="ch13">Near School</label>
                          </div>
                          <div className="padd">
                            <input type="checkbox" id="ch14" name="addcheck" />
                            <label for="ch14">Near Shop</label>
                          </div>
                          <div className="padd">
                            <input type="checkbox" id="ch15" name="addcheck" />
                            <label for="ch15">Oven</label>
                          </div>
                          <div className="padd">
                            <input type="checkbox" id="ch16" name="addcheck" />
                            <label for="ch16">Coffee pot</label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="fnt4">File Uploads</div>
                    <div className="dpcontainer">
                      <div className="dad">
                        {" "}
                        <div className="clouds">
                          <FontAwesomeIcon
                            className="cloud"
                            size="3x"
                            icon={faCloudArrowUp}
                          />
                        </div>
                        <div className="fnt5">
                          <input type="file" className="fnt6" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="ms-Grid">
                <div className="ms-Grid-row">
                  <div className="ms-Grid-col ms-lg12 sad">
                    <button
                      onClick={() => {
                        handleSubmit();
                      }}
                      className="fsubmit"
                      type="submit"
                    >
                      Submit
                    </button>
                    <button className="fdelete">Delete</button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
