import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import Dropdown from "react-dropdown";
import "../../CSS/dropdown.css";
import Options from "../../jsonData/options.json";

export default function Dropdowns() {
  return (
    <div className="dps">
      <div className="fnt">Search</div>
      <div>
        {Options &&
          Options.map((option) => {
            return (
              <div key={option.name} className="dps1">
                <Dropdown
                  options={option.options}
                  placeholder={option.name}
                />
              </div>
            );
          })}
      </div>
      <div className="search2">
        <button className="flx search1">
          <div>
            <FontAwesomeIcon className="pq-7 search" icon={faMagnifyingGlass} />
          </div>
          <div className="p-7 fnt1 search">Search</div>
        </button>
      </div>
    </div>
  );
}
