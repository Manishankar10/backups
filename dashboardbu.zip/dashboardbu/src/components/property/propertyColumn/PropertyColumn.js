import React, { useEffect, useState } from "react";
import DropdownsColumn from "../DropDownsColumn";
import Properties1 from "../../../jsonData/PropertyColumn.json";
import PropertiesClm from "./PropertiesClm";
import Pagination from "../propertyList/Pagination";

export default function PropertyColumn() {
  const [posts, setPosts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(6);

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPost = posts.slice(indexOfFirstPost, indexOfLastPost);

  const paginate=(pageNumber)=> setCurrentPage(pageNumber);
  useEffect(()=>{
    const fetch =() =>{
      setPosts(Properties1)
    };
    fetch();
  },[])
  return (
    <div className="ms-Grid bgc">
      <div className="ms-Grid-row flx">
        <div className="ms-Grid-col ms-lg12">
          {" "}
          <DropdownsColumn />
        </div>
      </div>
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12 ms-md12  ms-lg12 ">
          <PropertiesClm currentPost={currentPost}/>
         <div className="pgnation"> <Pagination  postsPerPage={postsPerPage} totalPosts={posts.length} paginate={paginate} />
      </div>  </div>
      </div>
    </div>
  );
}
