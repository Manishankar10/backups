import { faLocationDot } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import {useNavigate} from 'react-router-dom'

export default function PropertiesClm({currentPost}) {
  const nav=useNavigate()
  const handleDetails=(id)=>{
    var index=currentPost.findIndex(function(x){
      return x.id===id
    })
    var data=currentPost[index]
    nav('/propertyDetails',{state:{
      image:data.house,
      address:data.address,
      price:data.Price,
      status:data.status
    }})
  }
  return (
    <div className='pcflex'>{currentPost &&
      currentPost.map((property) => {
          return (
            <div key={property.id} className="pcflex1">
              <img className="pcimg" src={property.house} alt="homeimg" />
              <div className="sorr1">
                    {property.status === "Sale" ? (
                      <div className="sale1">
                        <strong>FOR SALE</strong>
                      </div>
                    ) : (
                      <div className="rent1">
                        <strong>FOR RENT</strong>
                      </div>
                    )}
                  </div>
              <div className="pcprc">{property.Price}</div>
              <div className="pcad">{property.address}</div>
              <div className="pcloc">
                <FontAwesomeIcon
                  className="pe-3"
                  icon={faLocationDot}
                  size="xs"
                />
                {property.loc}
              </div>
              <div className="flx pcmss">
                <div>
                  <div className="pcsqt">{property.sqft}</div>
                  <div className="addfrminp">Square feet</div>
                </div>
                <div>
                  <div className="pcsqt">{property.bedrooms}</div>
                  <div className="addfrminp">Bedrooms</div>
                </div>
                <div>
                  <div className="pcsqt">{property.parkingSpace}</div>
                  <div className="addfrminp">Parking Space</div>
                </div>
              </div>
              <div className="pcbtn">
                <button onClick={()=>{handleDetails(property.id)}} className="vd">View Details</button>
              </div>
            </div>
          );
        })}</div>
  )
}
