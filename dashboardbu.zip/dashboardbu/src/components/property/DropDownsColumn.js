import React from "react";
import Options from "../../jsonData/options.json";
import Dropdown from "react-dropdown";
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function DropDownsColumn() {
  return (
    <div>
      <div className="fnt2">Search Properties</div>
      <div className="ms-Grid ms-2p p-5 mt-1p">
        <div className="ms-Grid-row flx">
          <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg3">
            <div className="ps">
              <Dropdown
                options={Options[0].options}
                placeholder={Options[0].name}
              />
            </div>
          </div>
          <div className="ms-Grid-col ms-sm12 ms-md6  ms-lg3">
            <div className="ps">
              <Dropdown
                options={Options[1].options}
                placeholder={Options[1].name}
              />
            </div>
          </div>
          <div className="ms-Grid-col ms-sm12 ms-md6  ms-lg3">
            <div className="ps">
              <Dropdown
                options={Options[2].options}
                placeholder={Options[2].name}
              />
            </div>
          </div>
          <div className="ms-Grid-col ms-sm12 ms-md6  ms-lg3">
            <div className="ps">
              <Dropdown
                options={Options[3].options}
                placeholder={Options[3].name}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="sch mt-1p">
        {" "}
        <div className="search2">
          <button className="flx search1">
            <div>
              <FontAwesomeIcon
                className="pq-7 search"
                icon={faMagnifyingGlass}
              />
            </div>
            <div className="p-7 fnt1 search">Search</div>
          </button>
        </div>
      </div>
    </div>
  );
}
