import React, { useEffect, useState } from "react";
import PropertyList2 from "../../../jsonData/PropertyList.json";
import Dropdowns from "../Dropdowns";
import Properties from "./Properties";
import Pagination from "./Pagination";
export default function PropertyList() {
  const [posts, setPosts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(5);

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPost = posts.slice(indexOfFirstPost, indexOfLastPost);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  useEffect(() => {
    const fetch = () => {
      setPosts(PropertyList2);
    };
    fetch();
  }, []);
  return (
    <div className="ms-Grid gray">
      <div className="ms-Grid-row p-8 ms-1p fnt">Property List</div>
      <div className="ms-Grid-row flx">
        <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg7">
          <Properties currentPost={currentPost} />
          <Pagination
            postsPerPage={postsPerPage}
            totalPosts={posts.length}
            paginate={paginate}
          />
        </div>
        <div className="ms-Grid-col ms-sm12 sm-md12 ms-lg5 ">
          <Dropdowns />
        </div>
      </div>
      <div></div>
    </div>
  );
}
