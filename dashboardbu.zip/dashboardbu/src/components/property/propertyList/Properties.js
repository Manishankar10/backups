import React from "react";
import {
    faBed,
    faCar,
    faChargingStation,
    faHeart,
    faLocationDot,
    faTableCellsLarge,
  } from "@fortawesome/free-solid-svg-icons";
  import {useNavigate} from 'react-router-dom'
  import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function Properties({ currentPost }) {
  const nav=useNavigate()
  const handleDetails=(id)=>{
    var index=currentPost.findIndex(function(x){
      return x.id===id
    })
    var data=currentPost[index]
    nav('/propertyDetails',{state:{
      image:data.house,
      address:data.address,
      price:data.price,
      status:data.status
    }})
  }
  return (
    <div>
      {" "}
      {currentPost &&
        currentPost.map((property) => {
          return (
            <div onClick={()=>{handleDetails(property.id)}} key={property.id} className="ms-Grid-row ">
              <div className="flx card">
                <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg4">
                  <img
                    className="plimg"
                    src={property.house}
                    alt="propertyimg"
                  />
                  <div className="sorr">
                    {property.status === "Sale" ? (
                      <div className="sale">
                        <strong>FOR SALE</strong>
                      </div>
                    ) : (
                      <div className="rent">
                        <strong>FOR RENT</strong>
                      </div>
                    )}
                  </div>
                </div>
                <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg8 pl60">
                  <div className="lightgreen pb7 pt-1p">
                    <strong>{property.price}</strong>
                  </div>
                  <div className="fnt pb7">{property.address}</div>
                  <div className="flx pb-10">
                    <div className="pe-3">
                      <FontAwesomeIcon icon={faLocationDot} size="xs" />
                    </div>
                    <div>{property.loc}</div>
                  </div>
                  <div className="pb-10">{property.des}</div>
                  <div>
                    <div
                      style={{
                        borderTop: "2px solid #d3d3d3 ",
                        marginLeft: 5,
                        marginTop: 24,
                      }}
                    ></div>
                  </div>
                  <div className="flx jspacebwn">
                    <div className="p-9">
                      <button className="tooltip me-3">
                        <FontAwesomeIcon
                          className="pe-5"
                          icon={faTableCellsLarge}
                        />
                        280
                        <span className="tooltiptext">280 square feet</span>
                      </button>
                      <button className="tooltip me-3">
                        <FontAwesomeIcon className="pe-5" icon={faBed} />4
                        <span className="tooltiptext">4 Bedroom House</span>
                      </button>
                      <button className="tooltip me-3">
                        <FontAwesomeIcon className="pe-5" icon={faCar} />2
                        <span className="tooltiptext">2 Parking Space</span>
                      </button>
                      <button className="tooltip me-3">
                        <FontAwesomeIcon
                          className="pe-5"
                          icon={faChargingStation}
                        />
                        24H
                        <span className="tooltiptext">24h Electricity</span>
                      </button>
                    </div>
                    <div className="p-9">
                      <button className=" save flx">
                        <div>
                          <FontAwesomeIcon className="heart" icon={faHeart} />
                        </div>
                        <div className="ms-3">Save</div>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
    </div>
  );
}
