import { faAngleLeft, faAngleRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';

export default function Pagination({postsPerPage, totalPosts ,paginate}) {
    const pageNumbers=[];
    for(let i=1; i<=Math.ceil(totalPosts / postsPerPage);i++){
        pageNumbers.push(i);
    }
  return (
    <nav className='page-nav'>
        <ul className='page-ul'>
            <li className='page-li'><FontAwesomeIcon icon={faAngleLeft} /></li>
            {pageNumbers.map(number =>(
                <li className='page-li' key={number}>
                    <button className='a' onClick={(e)=>{ paginate(number);e.preventDefault()}} href='/propertyList'>
                        {number}
                    </button>
                </li>
            ))}
            <li className='page-li'><FontAwesomeIcon icon={faAngleRight} /></li>
        </ul>
    </nav>
  )
}
