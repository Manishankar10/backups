import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck, faLocationDot } from "@fortawesome/free-solid-svg-icons";
import TopRatedAgent from "../dashboard/TopRatedAgent";
import { useLocation } from "react-router-dom";

export default function PropertyDetails() {
  const loc=useLocation()
  let name = "Agent";
  let rating = "(29)";
  return (
    <div className="bgc">
      <div className="fnt6">Property Detail</div>
      <div className="ms-Grid">
        <div className="ms-Grid-row flx">
          <div className="ms-Grid-col ms-sm12 ms-md7 ms-lg6">
            <div className="pd">
              <div>
                <img className="pd-img" src={loc.state.image} alt="" />
              </div>
              <div className="pdad">{loc.state.address}</div>
              <div className="lgray pt-1p">
                <FontAwesomeIcon
                  className="pe-6"
                  icon={faLocationDot}
                  size="xs"
                />
                245 E 20th St, New York, NY 201609
              </div>
              <div className="lgray">
                <p className="p">
                  Quisque non dictum eros. Praesent porta vehicula arcu eu
                  ornare. Donec id egestas arcu. Suspendisse auctor condimentum
                  ligula ultricies cursus. Vestibulum vel orci vel lacus rhoncus
                  sagittis sed vitae mi. Pellentesque molestie elit bibendum
                  tincidunt semper. Aliquam ac volutpat risus. In felis felis,
                  posuere commodo aliquet eget, sagittis sed turpis. Phasellus
                  commodo turpis non nunc egestas, et egestas felis pretium.
                  Pellentesque dignissim libero vitae tincidunt semper. Nam id
                  ante nisi. Nam sollicitudin, dolor non suscipit feugiat, nibh
                  lacus commodo metus, nec tempus dui velit sagittis velit.
                  Pellentesque elementum risus rhoncus justo porta, at varius
                  odio consequat. Duis non augue adipiscing, posuere quam non,
                  tempus urna.
                </p>
              </div>
              <div>
                <div className="ga">General Amenities</div>
                <div className="flx jcsp">
                  <div className="ga-checks">
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />
                      Swimming pool
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Air conditioning
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />
                      Internet
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />
                      Radio
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />
                      Balcony
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Roof terrace
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Cable TV
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Electricity
                    </div>
                  </div>
                  <div className="ga-checks">
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Terrace
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Cofee pot
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Oven
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Towelwes
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />
                      Computer
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Grill
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Parquet
                    </div>
                  </div>
                  <div className="ga-checks">
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Dishwasher
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Near Green Zone
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Near Church
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Near Hospital
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Near School
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />
                      Near Shop
                    </div>
                    <div>
                      <FontAwesomeIcon
                        size="xs"
                        className="fcc"
                        icon={faCheck}
                      />{" "}
                      Natural Gas
                    </div>
                  </div>
                </div>
              </div>
              <div className="ga">Location</div>
              <div className="location">
                <div className="location1"></div>
              </div>
            </div>
          </div>
          <div className="ms-Grid-col ms-sm12 ms-md5 ms-lg6">
            <div className="pdag">
              <TopRatedAgent name={name} rating={rating} />{" "}
            </div>
            <div className="pd-table">
              <div className="pd-table1">
                <table className="pdtable">
                  <tbody>
                    <tr>
                      <td className="pdtabletd pdtd pdtd1">Price:</td>
                      <td className="pdtd pdtd1">{loc.state.price}</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Contract type:</td>
                      <td className="pdtd">{loc.state.status}</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Bathrooms:</td>
                      <td className="pdtd">1.5</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Square ft:</td>
                      <td className="pdtd">468</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Garage Spaces:</td>
                      <td className="pdtd">2</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Land Size:</td>
                      <td className="pdtd">721 m²</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Floors:</td>
                      <td className="pdtd">2</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Listed for:</td>
                      <td className="pdtd">15 days</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Available:</td>
                      <td className="pdtd">Immediately</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Pets:</td>
                      <td className="pdtd">Pets Allowed</td>
                    </tr>
                    <tr>
                      <td className="pdtabletd pdtd">Bedrooms:</td>
                      <td className="pdtd">3</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
