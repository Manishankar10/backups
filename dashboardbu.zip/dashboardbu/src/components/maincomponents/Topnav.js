import React from "react";
import zircos from "../../images/zircos.png";
import avatar from "../../images/avatar-1.jpg";
import us from "../../images/us.jpg";
import { SearchBox } from "@fluentui/react/lib/SearchBox";
import { Dropdown } from "@fluentui/react/lib/Dropdown";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBell, faEnvelope, faGear } from "@fortawesome/free-solid-svg-icons";

export default function Topnav() {
  const searchBoxStyles = {
    root: { width: 200, borderRadius: 50, backgroundColor: "#475263" },
  };
  const dropdownStyles = {
    dropdown: { width: 130 },
  };

  const options = [
    {
      key: "Germen",
      text: "Germen",
    },
    { key: "Russian", text: "Russian" },
    { key: "Chinese", text: "Chinese" },
    { key: "Tamil", text: "Tamil" },
    { key: "Japanese", text: "Japanese" },
  ];
  return (
    <div className="ms-Grid">
      <div className="nav1 ms-Grid-row">
        <div className="ms-Grid-col ms-lg1">
          <img
            src={zircos}
            alt="logo"
            style={{ width: "90px", padding: "15px" }}
          />
        </div>
        <div className="searchbox ms-Grid-col ms-lg8">
          <SearchBox
            className="search"
            styles={searchBoxStyles}
            placeholder="Search..."
          />
        </div>
        <div className="dp">
          <Dropdown
            placeholder={
              <div className="flx">
                <div>
                  <img
                    src={us}
                    alt="user"
                    style={{ width: "17px", padding: "10px" }}
                  />
                </div>
                <div>English</div>
              </div>
            }
            options={options}
            styles={dropdownStyles}
          />
        </div>
        <div className="dp1">
          <FontAwesomeIcon icon={faBell} />
        </div>
        <div className="dp1">
          <FontAwesomeIcon icon={faEnvelope} />
        </div>
        <div>
          <img
            src={avatar}
            alt="user"
            style={{ width: "30px", padding: "17px", borderRadius: 50 }}
          />
        </div>
        <div className="dp1">
          <FontAwesomeIcon icon={faGear} />
        </div>
      </div>
    </div>
  );
}
