import React from "react";
import { Link } from "@fluentui/react";
export default function MenuBar() {
  return (
    <div className="ms-Grid">
      <div className="ms-Grid-row flx1">
        <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg3">
          <Link href="/" className="linker">
            Dashboard
          </Link>
        </div>
        <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg3">
          {" "}
          <Link className="dpd linker">
            Property
            <div className="dp-content ">
              <div>
                <a href="/propertyList">Property List</a>
              </div>
              <div>
                <a href="/propertyColumn">Property Column</a>
              </div>
            </div>
          </Link>
        </div>
        <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg3">
          {" "}
          <Link className="dpd linker">
            Agents
            <div className="dp-content ">
              <div>
                <a href="/agents">AgentList</a>
              </div>
            </div>
          </Link>
        </div>
        <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg3">
          {" "}
          <Link className="linker" href="/addproperty">
            Add Property
          </Link>
        </div>
      </div>
    </div>
  );
}
