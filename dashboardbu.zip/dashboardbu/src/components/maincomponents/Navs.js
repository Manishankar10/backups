import React from "react";
import MenuBar from "./MenuBar";
import Topnav from "./Topnav";

export default function Navs() {
  return (
    <div>
      {" "}
      <div className="topnav">
        <Topnav />
      </div>
      <div className="menubar">
        <MenuBar />
      </div>
    </div>
  );
}
