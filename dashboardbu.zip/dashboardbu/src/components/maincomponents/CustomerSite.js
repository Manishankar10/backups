import React from "react";
import Dashboard from "../dashboard/Dashboard";

export default function CustomerSite() {
  return (
    <div>
      <div className="gray">
        <Dashboard />
      </div>
    </div>
  );
}
