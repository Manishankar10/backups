import { faCopyright } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";

export default function Footer() {
  return (
    <div className="footer">
      <div className="ftxt">
        {" "}
        <div className="pe-3">2018 - 2020</div>
        <div className="pe-3">
          <FontAwesomeIcon className="ficon" size="sm" icon={faCopyright} />
        </div>
        <div>
          Zircos theme by{" "}
          <a className="flink" href="/">
            Coderthemes
          </a>
        </div>
      </div>
    </div>
  );
}
