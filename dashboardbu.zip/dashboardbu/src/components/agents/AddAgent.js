import { faX } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import Modal from "react-modal";
export default function AddAgent(props) {
  const [modalIsOpen, setIsOpen] = useState(false);
  const [state, setState] = useState({
    name: "",
    email: "",
    contactNum: 0,
    listedProperties: "",
    image: `${"images/user4.jpg"}`
  });
  const handleSave = (e) => {
    e.preventDefault();
    props.saveData(state)
    setIsOpen(false);
  };
  const handleChange = (e) => {
    setState((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };
  function openModal() {
    setIsOpen(true);
  }

  function closeModal() {
    setIsOpen(false);
  }
  const customStyles = {
    content: {
      top: "40%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      transform: "translate(-50%, -50%)",
    },
  };
  return (
    <div>
      <button onClick={openModal} className="agadd">
        Add Agent
      </button>
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        style={customStyles}
        contentLabel="Example Modal"
      >
        <div className="popuphead">
          <div className="flx">
            <div className="head1">Add New Agent</div>
            <div className="canic">
              <FontAwesomeIcon onClick={closeModal} icon={faX} />
            </div>
          </div>
        </div>
        <div className="addform">
          <form>
            <div className="addfrminp">
              <div>
                <label>Name</label>
              </div>
              <div>
                <input
                  onChange={(e) => {
                    handleChange(e);
                  }}
                  value={state.name}
                  name="name"
                  type="text"
                  placeholder="Enter Name"
                  className="inp"
                />
              </div>
            </div>
            <div className="addfrminp">
              <div>
                <label>E-mail</label>
              </div>
              <div>
                <input
                  onChange={(e) => {
                    handleChange(e);
                  }}
                  value={state.email}
                  name="email"
                  type="email"
                  placeholder="Enter Email"
                  className="inp"
                />
              </div>
            </div>
            <div className="addfrminp">
              <div>
                <label>Contact Number</label>
              </div>
              <div>
                <input
                  onChange={(e) => {
                    handleChange(e);
                  }}
                  value={state.contactNum}
                  name="contactNum"
                  type="number"
                  placeholder="Enter Contact"
                  className="inp"
                />
              </div>
            </div>
            <div className="addfrminp">
              <div>
                <label>Listed Properties</label>
              </div>
              <div>
                <input
                  onChange={(e) => {
                    handleChange(e);
                  }}
                  value={state.listedProperties}
                  name="listedProperties"
                  type="text"
                  placeholder="Number of properties"
                  className="inp"
                />
              </div>
            </div>
            <div className="addfrminp fmbutton">
              <div>
                <button
                  onClick={(e) => {
                    handleSave(e);
                  }}
                  className="fmsave"
                >
                  Save
                </button>
              </div>
              <div className="ms-1p">
                <button className="fmcancel">Cancel</button>
              </div>
            </div>
          </form>
        </div>
      </Modal>
    </div>
  );
}
