import { SearchBox } from "@fluentui/react";

import React, { useEffect, useState } from "react";
import AgentData from "../../jsonData/agent.json";
import AddAgent from "./AddAgent";
import AgentList from "./AgentList";
import Pagination from "../property/propertyList/Pagination";

export default function Agents() {
  let temp;
  localStorage.setItem("agents", JSON.stringify(AgentData));
  var storedNames = JSON.parse(localStorage.getItem("agents"));


  const [posts, setPosts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(10);

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPost = posts.slice(indexOfFirstPost, indexOfLastPost);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  useEffect(() => {
    const fetch = () => {
      setPosts(JSON.parse(localStorage.getItem("agents")));
    };
    fetch();
  }, []);
  const [search, setSearch] = useState("");

  const [agData, setAgData] = useState([]);
  useEffect(() => {
    setAgData(AgentData);
  }, []);

  const saveData = (newAgent) => {
    temp = agData;
    temp.push({
      id: temp.length + 1,
      name: newAgent.name,
      email: newAgent.email,
      ["contact.no"]: newAgent.contactNum,
      listedProperties: newAgent.listedProperties,
      image: `${"images/user4.jpg"}`,
    });
    localStorage.setItem("agents",JSON.stringify(temp))
    setPosts(JSON.parse(localStorage.getItem("agents")));
  };
  const searchBoxStyles = {
    root: { borderRadius: 50, height: 45 },
  };
  return (
    <div className="gray agent">
      <div className="fnt ms-1p">Agents</div>
      <div>
        <div className="ms-Grid agentbox">
          <div className="ms-Grid-row flx agtable">
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg6">
              <SearchBox
                placeholder="Search here..."
                onChange={(e) => {
                  setSearch(e.target.value);
                }}
                styles={searchBoxStyles}
              />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg2">
              <AddAgent
                saveData={(e) => {
                  saveData(e);
                }}
              />
            </div>
          </div>
          <div className="ms-Grid-row">
            <div className="ms-Grid-col ms-lg12">
              <AgentList
                agData={agData}
                search={search}
                currentPost={currentPost}
                storedNames={storedNames}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="pgnation2">
        <Pagination
          postsPerPage={postsPerPage}
          totalPosts={agData.length}
          paginate={paginate}
        />
      </div>
    </div>
  );
}
