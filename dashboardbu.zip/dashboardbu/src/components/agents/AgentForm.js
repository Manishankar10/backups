import React from "react";

export default function AgentForm() {
  return (
    <div>
      <form>
        <div className="fnt7">Get in Touch</div>
        <div className="fnt8">
          <label>Name</label>
          <div>
            <input className="inp5" placeholder="Enter Name" />{" "}
          </div>
        </div>
        <div className="fnt8">
          <label>Email address</label>
          <div>
            <input className="inp5" placeholder="Enter email" />{" "}
          </div>
        </div>
        <div className="fnt8">
          <label>Message</label>
          <textarea className="inp6" />
        </div>
        <div className="sbtn">
          <button className="sbtn1">Submit</button>
        </div>
      </form>
    </div>
  );
}
