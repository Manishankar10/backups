import React, { useEffect, useState } from "react";
import { faPen, faX } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Checkbox } from "@fluentui/react";
import { useNavigate } from "react-router-dom";

export default function AgentList({ agData, search, currentPost,storedNames }) {
  let arr1=currentPost
  const [arr,setArr]=useState()
  const HandleDelete = (e, a) => {
    arr1 = arr1.filter((x) => x.id !== a);
    setArr(arr1)
  };
  useEffect(()=>{
    setArr(arr1)
  },[arr1])
  const handleAgent = (id) => {
    var data = agData[id - 1];
    nav("/agentDetails", {
      state: {
        name: data.name,
        img: data.image,
        cnno: data["contact.no"],
        email: data.email,
      },
    });
  };
  const nav = useNavigate();

  return (
    <div>
      <table className="agenttable">
        <thead>
          <tr>
            <th>
              <Checkbox />
              {console.log(storedNames)}
            </th>
            <th></th>
            <th>Name</th>
            <th>E-mail</th>
            <th>Contact.number</th>
            <th>listedProperties</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {arr &&
            arr
              .filter((val) => {
                if (search === "") {
                  return val;
                } else if (
                  val.name.toLowerCase().includes(search.toLowerCase()) ||
                  val.email.toLowerCase().includes(search.toLowerCase()) ||
                  String(val["contact.no"])
                    .toLowerCase()
                    .includes(search.toLowerCase()) ||
                  val.listedProperties
                    .toLowerCase()
                    .includes(search.toLowerCase())
                ) {
                  return val;
                }
              })
              .map((agent) => {
                return (
                  <tr key={agent.id}>
                    <td>
                      <Checkbox />
                    </td>
                    <td
                      onClick={() => {
                        handleAgent(agent.id);
                      }}
                    >
                      <img className="agimg" src={agent.image} alt="agntimg" />
                    </td>
                    <td
                      onClick={() => {
                        handleAgent(agent.id);
                      }}
                    >
                      {agent.name}
                    </td>
                    <td
                      onClick={() => {
                        handleAgent(agent.id);
                      }}
                    >
                      {agent.email}
                    </td>
                    <td
                      onClick={() => {
                        handleAgent(agent.id);
                      }}
                    >
                      {agent["contact.no"]}
                    </td>
                    <td
                      onClick={() => {
                        handleAgent(agent.id);
                      }}
                    >
                      {agent.listedProperties}
                    </td>
                    <td>
                      {" "}
                      <div className="flx">
                        <button className="pen">
                          <FontAwesomeIcon icon={faPen} />
                        </button>
                        <button
                          onClick={(e) => {
                            HandleDelete(e, agent.id);
                          }}
                          className="cross ms-2"
                        >
                          <FontAwesomeIcon icon={faX} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
        </tbody>
      </table>
    </div>
  );
}
