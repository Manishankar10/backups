import React, { useEffect, useState } from "react";
import AgentCard from "./AgentCard";
import AgentForm from "./AgentForm";
import Properties1 from "../../jsonData/PropertyColumn.json";
import { useLocation } from "react-router-dom";
import AgentProperties from "./AgentProperties";
import Pagination from "../property/propertyList/Pagination";

export default function AgentDetails() {
  const [posts, setPosts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(6);

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPost = posts.slice(indexOfFirstPost, indexOfLastPost);

  const paginate=(pageNumber)=> setCurrentPage(pageNumber);
  useEffect(()=>{
    const fetch =() =>{
      setPosts(Properties1)
    };
    fetch();
  },[])
  const [star] = useState("("+ String(Math.floor(((Math.random() * 10)+30)))+")");
  const location = useLocation();
  return (
    <div className="bgc">
      <div className="fnt6">Agent Profile</div>
      <div>
        <div className="ms-Grid agentD">
          <div className="ms-Grid-row agflx">
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg3">
              <div className=" ms-Grid agentcard">
                <div className="ms-Grid-row">
                  <div className="ms-Grid-col  ms-lg12">
                    <AgentCard
                      image={location.state.img}
                      name={location.state.name}
                      star={star}
                      phnum={location.state.cnno}
                      email={location.state.email}
                    />
                  </div>
                </div>
              </div>
              <div className="agentform">
                <AgentForm />
              </div>
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg9 ">
              <AgentProperties  currentPost={currentPost}/>
            <div  className="pgnation1">  <Pagination  postsPerPage={postsPerPage} totalPosts={posts.length} paginate={paginate}/>
            </div></div>
          </div>
        </div>
      </div>
    </div>
  );
}
