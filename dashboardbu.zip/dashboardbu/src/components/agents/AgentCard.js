import React from "react";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import f from "./brands/facebook-f.svg";
import t from "./brands/twitter.svg";
import s from "./brands/skype.svg";
export default function AgentCard({ image, name, star, phnum, email }) {
  return (
    <div className="agcardimg">
      <img src={image} alt="agent" className="agcardimg1" />
      <div className="starcard">
        {" "}
        <FontAwesomeIcon size="2xs" className="starincard" icon={faStar} />
      </div>
      <div className="fnt6">{name}</div>
      <FontAwesomeIcon className="starin1" icon={faStar} />
      <FontAwesomeIcon className="starin1" icon={faStar} />
      <FontAwesomeIcon className="starin1" icon={faStar} />
      <FontAwesomeIcon className="starin1" icon={faStar} />
      <FontAwesomeIcon className="starin1" icon={faStar} />
      {star ? star : null}
      <div className="agbtns">
        <button onClick={()=>{alert("You started following",name)}} className="agflw" type="submit">
          Follow
        </button>
        <button className="agmsg">Message</button>
      </div>
      <div className="agp">
        <p>
          Hi I'm {name},has been the industry's standard dummy text ever since
          the 1500s, when an unknown printer took a galley of type.
        </p>
      </div>
      <div className="horizontalline"></div>
      <div className="aginfo flx">
        <div className="hds">Full Name:</div>
        <div className="infs">jonathan {name} Deo</div>
      </div>
      <div className="aginfo flx">
        <div className="hds">Mobile:</div>
        <div className="infs">(123) {phnum}</div>
      </div>
      <div className="aginfo flx">
        <div className="hds">Email:</div>
        <div className="infs">{email}</div>
      </div>
      <div className="aginfo flx">
        <div className="hds">Location:</div>
        <div className="infs">USA</div>
      </div>
      <div className="brands flx">
        <button className="tooltip f-btn">
          <img className="f" src={f} alt="" />{" "}
          <span className="tooltiptext">Facebook</span>
        </button>
        <button className="tooltip f-btn">
          <img className="t" src={t} alt="" />{" "}
          <span className="tooltiptext">Twitter</span>
        </button>
        <button className="tooltip f-btn">
          <img className="s" src={s} alt="" />{" "}
          <span className="tooltiptext">Skype</span>
        </button>
      </div>
    </div>
  );
}
