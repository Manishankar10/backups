import React from 'react';
import Properties1 from "../../jsonData/PropertyColumn.json";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationDot } from "@fortawesome/free-solid-svg-icons";

export default function AgentProperties({currentPost}) {
  return (
    <div className='pcflex2'>{currentPost &&
        currentPost.map((property) => {
          return (
            <div className="pcflex11">
            <div key={property.id} >
              <img
                className="pcimg1"
                src={property.house}
                alt="homeimg"
              />
              <div className="pcprc1">{property.Price}</div>
              <div className="pcad1">{property.address}</div>
              <div className="pcloc1">
                <FontAwesomeIcon
                  className="pe-3"
                  icon={faLocationDot}
                  size="xs"
                />
                {property.loc}
              </div>
              <div className="flx pcmss1">
                <div>
                  <div className="pcsqt1">{property.sqft}</div>
                  <div className="addfrminp1">Square feet</div>
                </div>
                <div>
                  <div className="pcsqt1">{property.bedrooms}</div>
                  <div className="addfrminp1">Bedrooms</div>
                </div>
                <div>
                  <div className="pcsqt1">{property.parkingSpace}</div>
                  <div className="addfrminp1">Parking Space</div>
                </div>
              </div>
              <div className="pcbtn1">
                <button className="vd1">View Details</button>
              </div>
            </div></div>
          );
        })}</div>
  )
}
