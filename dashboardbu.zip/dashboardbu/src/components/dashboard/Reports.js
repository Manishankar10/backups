import React, { useState } from "react";
import Chart from "react-apexcharts";
export default function Reports() {
  const [state] = useState({
    options: {
      chart: {
        id: "apexchart-example",
      },
      xaxis: {
        categories: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
      },
      fill: {
        colors: ["lightgray", "rgba(63, 191, 223, 0.966)", "rgb(3, 151, 114)"],
      },
    },
    series: [
      {
        name:"Revenue",data: [18, 24, 12, 4, 1, 13, 29, 28, 11, 4, 11],color:"lightgray"
      },
      {
        name:"Listed Properties",data: [23, 4, 16, 20, 24, 16, 15, 1, 12, 14, 1],color:"rgba(63, 191, 223, 0.966)"
      },
      {
        name:"User Registered",data: [20, 6, 25, 19, 10, 16, 14, 19, 5, 7, 24],color:"rgb(3, 151, 114)"
      },
    ],
  });
  return (
    <Chart
      options={state.options}
      series={state.series}
      type="bar"
      width={1000}
      height={450}
    />
  );
}
