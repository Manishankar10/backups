import React from "react";
import Users from "../../jsonData/recentUser.json";
import { DefaultButton } from "@fluentui/react/lib/Button";

export default function RecentUsers() {
  return (
    <div>
      <div className="tableb">
        <h3>Recent Users</h3>
      </div>
      <div className="tableb">
        {Users &&
          Users.map((user) => {
            return (
              <div key={user}>
                {" "}
                <table className="table">
                  <thead></thead>
                  <div className="tableb ">
                    <tbody>
                      <tr>
                        <div className="flx">
                          <div>
                            <td className="tbimgs">
                              <img
                                src={user.image}
                                alt="userimg"
                                className="timages"
                              />
                            </td>
                          </div>
                          <div className="ruinfo1">
                            <td  className="ruinfo" >
                              {
                                <div>
                                  <div>
                                    <strong>{user.name}</strong>
                                  </div>
                                  <div>{user.login}</div>
                                </div>
                              }
                            </td>
                          </div>
                          <div className="rubtns1"> 
                            {" "}
                            <td className="flx rubtns">
                              <div style={{ paddingLeft: 10, paddingTop: 10 }}>
                                <DefaultButton text="Edit" className="btn1" />
                              </div>
                              <div style={{ paddingLeft: 10, paddingTop: 10 }}>
                                <DefaultButton text="Remove" className="btn2" />
                              </div>
                            </td>
                          </div>
                        </div>
                      </tr>
                    </tbody>
                  </div>
                </table>
              </div>
            );
          })}
      </div>
    </div>
  );
}
