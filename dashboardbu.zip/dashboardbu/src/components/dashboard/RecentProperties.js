import React from "react";
import Properties from "../../jsonData/recentProperties.json";
export default function RecentProperties() {
  return (
    <div>
      <div className="tableb">
        <h3>Recent Properties</h3>
      </div>
      <div className="tableb">
        {Properties &&
          Properties.map((property) => {
            return (
              <div key={property.id} className="propertyb flx">
                <div>
                  <img
                    src={property.house}
                    alt="propertimg"
                    className="himages"
                  />
                </div>
                <div style={{ marginLeft: 14 }}>
                  <div style={{ marginBottom: 13, color: "#979797" }}>
                    <strong>{property.address}</strong>
                  </div>
                  <div>{property.dtandName}</div>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
}
