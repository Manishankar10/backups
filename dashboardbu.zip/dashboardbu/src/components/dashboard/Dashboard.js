import {
  faDollarSign,
  faHouseUser,
  faMessage,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import RecentProperties from "./RecentProperties";
import RecentUsers from "./RecentUsers";
import Reports from "./Reports";
import TopRatedAgent from "./TopRatedAgent";
import AnimatedNumber from "animated-number-react";

export default function Dashboard() {
  let name = "Top Rated Agent";
  const [state1] = useState({
    value: 12455,
    duration: 300,
  });
  const [state2] = useState({
    value: 1452,
    duration: 300,
  });
  const [state3] = useState({
    value: 1587,
    duration: 300,
  });
  const [state4] = useState({
    value: 46782,
    duration: 300,
  });
  return (
    <div>
      <div className="ms-Grid" >
        <div className="ms-Grid-row red">
          <div className="flx">
            <div className="ms-Grid-col ms-lg3 ms-md6 ms-sm12">
              <div className="mr flx">
                <div className="red">
                  <h4 className="mrc">THIS MONTH REVENUE</h4>
                  <div>
                    <h1>
                      $
                      {
                        <AnimatedNumber
                          value={state1.value}
                          duration={state1.duration}
                        />
                      }
                    </h1>
                  </div>
                </div>
                <div className="icn">
                  <FontAwesomeIcon size="2x" icon={faDollarSign} />
                </div>
              </div>
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg3">
              {" "}
              <div className="tp flx">
                <div className="red">
                  <h4 className="tpc">TOTAL PROPERTIES</h4>
                  <div>
                    <h1>
                      {
                        <AnimatedNumber
                          value={state2.value}
                          duration={state2.duration}
                        />
                      }
                    </h1>
                  </div>
                </div>
                <div className="icn">
                  <FontAwesomeIcon size="2x" icon={faHouseUser} />
                </div>
              </div>
            </div>
            <div className="ms-Grid-col ms-lg3 ms-md6 ms-sm12">
              {" "}
              <div className="mi flx">
                <div className="red">
                  <h4 className="mic">THIS MONTH INQUIRIES</h4>
                  <div>
                    <h1>
                      {
                        <AnimatedNumber
                          value={state3.value}
                          duration={state3.duration}
                        />
                      }
                    </h1>
                  </div>
                </div>
                <div className="icn">
                  <FontAwesomeIcon size="2x" icon={faMessage} />
                </div>
              </div>
            </div>
            <div className="ms-Grid-col ms-lg3 ms-md6 ms-sm12">
              {" "}
              <div className="ru flx">
                <div className="red">
                  <h4 className="ruc">REGISTERED USERS</h4>
                  <div>
                    <h1>
                      {
                        <AnimatedNumber
                          value={state4.value}
                          duration={state4.duration}
                        />
                      }
                    </h1>
                  </div>
                </div>
                <div className="icn">
                  <FontAwesomeIcon size="2x" icon={faUser} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="ms-Grid">
        <div className="ms-Grid-row ">
          <div className="flx">
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg7 chart">
              <Reports />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg4 tra">
              <TopRatedAgent name={name} />
            </div>
          </div>
        </div>
      </div>
      <div className="ms-Grid">
        <div className="ms-Grid-row ">
          <div className="ms-Grid-col flx">
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg5 chart">
              <RecentUsers />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg6 chart">
              <RecentProperties />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
