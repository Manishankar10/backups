import { faStar } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import avatar2 from "../../images/avatar-2.jpg";
import { DefaultButton } from "@fluentui/react/lib/Button";

export default function TopRatedAgent({ name, rating }) {
  const sendMessage = {
    root: {
      width: 141,
      height: 41,
      borderRadius: 50,
      color: "white",
      backgroundColor: "rgb(153, 106, 106)",
    },
  };
  return (
    <div className="ms-Grid">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12 ms-xs12 ms-lg12 bg">{name}</div>
      </div>
      <div className="ms-Grid-row tpagent">
        <div className="ms-Grid-col ms-sm12 ms-xs12 ms-lg12 ">
          <div>
            <img
              src={avatar2}
              alt="agent"
              style={{
                border: "1px solid lightgray",
                width: 100,
                borderRadius: 50,
                padding: "5px",
              }}
            />
            <div className="star">
              {" "}
              <FontAwesomeIcon className="starin" icon={faStar} />
            </div>
            <div style={{ paddingBottom: "14px" }}>
              Mark McKnight{rating ? rating : null}
            </div>
          </div>
          <FontAwesomeIcon className="starin1" icon={faStar} />
          <FontAwesomeIcon className="starin1" icon={faStar} />
          <FontAwesomeIcon className="starin1" icon={faStar} />
          <FontAwesomeIcon className="starin1" icon={faStar} />
          <FontAwesomeIcon className="starin1" icon={faStar} />
        </div>
      </div>
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12 ms-xs12 ms-lg12 flx red1">
          <div className="ms-Grid-col ms-lg2"></div>
          <div style={{ textAlign: "center" }} className="ms-Grid-col ms-sm12 ms-xs12 ms-lg4">
            <div style={{ fontSize: "25px" }}>84</div>
            <div style={{ color: "gray" }}>Listed Properties</div>
          </div>
          <div style={{ textAlign: "center" }} className="ms-Grid-col ms-sm12 ms-xs12 ms-lg3">
            <div style={{ fontSize: "25px" }}>58</div>
            <div style={{ color: "gray" }}>Sale Properties</div>
          </div>
        </div>
      </div>
      <div style={{ textAlign: "center" }} className="red1">
        <DefaultButton text="Send Message" styles={sendMessage} />
      </div>
    </div>
  );
}
