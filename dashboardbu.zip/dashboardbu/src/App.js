import CustomerSite from "./components/maincomponents/CustomerSite";
import { Routes, Route } from "react-router-dom";
import PropertyList from "./components/property/propertyList/PropertyList";
import PropertyColumn from "./components/property/propertyColumn/PropertyColumn";
import Navs from "./components/maincomponents/Navs";
import Agents from "./components/agents/Agents";
import AddProperty from "./components/addProperty/AddProperty";
import Footer from "./components/maincomponents/Footer";
import PropertyDetails from "./components/property/PropertyDetails";
import AgentDetails from "./components/agents/AgentDetails";

function App() {
  return (
    <>
      <Navs />
      <Routes>
        <Route path="/" element={<CustomerSite />} />
        <Route path="propertyList" element={<PropertyList />} />
        <Route path="propertyColumn" element={<PropertyColumn />} />
        <Route path="agents" element={<Agents />} />
        <Route path="addproperty" element={<AddProperty />} />
        <Route path="propertyDetails" element={<PropertyDetails />} />
        <Route path="agentDetails" element={<AgentDetails />} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
