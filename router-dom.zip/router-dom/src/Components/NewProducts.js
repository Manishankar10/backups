import React from 'react'

export const NewProducts = () => {
  return (
    <div>List of NewProducts</div>
  )
}
