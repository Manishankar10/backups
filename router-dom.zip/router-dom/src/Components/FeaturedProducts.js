import React from 'react'

export const FeaturedProducts = () => {
  return (
    <div>List of FeaturedProducts</div>
  )
}
