import React from 'react'

export const Nomatch = () => {
  return (
    <div>Page not found</div>
  )
}
