import { Routes, Route } from "react-router-dom";
import About from "./Components/About";
import { FeaturedProducts } from "./Components/FeaturedProducts";
import Home from "./Components/Home";
import Navbar from "./Components/Navbar";
import { NewProducts } from "./Components/NewProducts";
import { Nomatch } from "./Components/Nomatch";
import { OrderSummary } from "./Components/OrderSummary";
import { Products } from "./Components/Products";

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="order-summary" element={<OrderSummary />} />
        <Route path="*" element={<Nomatch />}></Route>
        <Route path="products" element={<Products />}>
          <Route index element={<FeaturedProducts />}/>
          <Route path='featured' element={<FeaturedProducts />}></Route>
          <Route path='new' element={<NewProducts />}></Route>
        </Route>
      </Routes>
    </>
  );
}

export default App;
